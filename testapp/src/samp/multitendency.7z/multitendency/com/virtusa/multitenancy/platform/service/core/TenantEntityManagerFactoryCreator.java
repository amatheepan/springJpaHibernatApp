package com.virtusa.multitenancy.platform.service.core;

import com.virtusa.multitenancy.domain.dto.DatabaseProperties;
import javax.naming.NamingException;

public abstract interface TenantEntityManagerFactoryCreator
{
  public abstract void createEntityManagerFactoryUsingJndiDataSource(String paramString1, String paramString2, String paramString3)
    throws NamingException;
  
  public abstract void createEntityManagerFactoryWithProvidedDatasource(DatabaseProperties paramDatabaseProperties, String paramString1, String paramString2);
}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.TenantEntityManagerFactoryCreator
 * JD-Core Version:    0.7.0.1
 */
package com.virtusa.multitenancy.platform.service.core;

import javax.sql.DataSource;

public abstract interface MultiTenantDataSource
  extends DataSource
{
  public abstract void addTenant(String paramString, DataSource paramDataSource);
}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.MultiTenantDataSource
 * JD-Core Version:    0.7.0.1
 */
package com.virtusa.multitenancy.domain.constant;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.PARAMETER})
public @interface TenantIdentification {}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.domain.constant.TenantIdentification
 * JD-Core Version:    0.7.0.1
 */
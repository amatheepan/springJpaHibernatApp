/*   1:    */ package com.virtusa.multitenancy.platform.service.core;
/*   2:    */ 
/*   3:    */ import java.io.PrintWriter;
/*   4:    */ import java.sql.Connection;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.sql.SQLFeatureNotSupportedException;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.concurrent.locks.Lock;
/*  10:    */ import java.util.concurrent.locks.ReadWriteLock;
/*  11:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*  12:    */ import javax.sql.DataSource;
/*  13:    */ import org.slf4j.LoggerFactory;
/*  14:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  15:    */ 
/*  16:    */ public class MultiTenantDataSourceImpl
/*  17:    */   implements MultiTenantDataSource
/*  18:    */ {
/*  19: 32 */   private static org.slf4j.Logger logger = LoggerFactory.getLogger(MultiTenantDataSourceImpl.class);
/*  20:    */   private DataSource defaultDataSource;
/*  21: 36 */   private Map<String, DataSource> tenantDataSources = new HashMap();
/*  22: 38 */   private ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*  23:    */   
/*  24:    */   public MultiTenantDataSourceImpl(DataSource defaultDataSource)
/*  25:    */   {
/*  26: 47 */     this.defaultDataSource = defaultDataSource;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Connection getConnection()
/*  30:    */     throws SQLException
/*  31:    */   {
/*  32: 57 */     return getDataSourceBasedOnTenant().getConnection();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Connection getConnection(String username, String password)
/*  36:    */     throws SQLException
/*  37:    */   {
/*  38: 68 */     return getDataSourceBasedOnTenant().getConnection(username, password);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public PrintWriter getLogWriter()
/*  42:    */     throws SQLException
/*  43:    */   {
/*  44: 78 */     return getDataSourceBasedOnTenant().getLogWriter();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getLoginTimeout()
/*  48:    */     throws SQLException
/*  49:    */   {
/*  50: 88 */     return getDataSourceBasedOnTenant().getLoginTimeout();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public java.util.logging.Logger getParentLogger()
/*  54:    */     throws SQLFeatureNotSupportedException
/*  55:    */   {
/*  56: 98 */     return getDataSourceBasedOnTenant().getParentLogger();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setLogWriter(PrintWriter arg0)
/*  60:    */     throws SQLException
/*  61:    */   {
/*  62:108 */     getDataSourceBasedOnTenant().setLogWriter(arg0);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setLoginTimeout(int arg0)
/*  66:    */     throws SQLException
/*  67:    */   {
/*  68:118 */     getDataSourceBasedOnTenant().setLoginTimeout(arg0);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isWrapperFor(Class<?> arg0)
/*  72:    */     throws SQLException
/*  73:    */   {
/*  74:128 */     return getDataSourceBasedOnTenant().isWrapperFor(arg0);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public <T> T unwrap(Class<T> arg0)
/*  78:    */     throws SQLException
/*  79:    */   {
/*  80:138 */     return getDataSourceBasedOnTenant().unwrap(arg0);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void addTenant(String tenantId, DataSource dataSource)
/*  84:    */   {
/*  85:150 */     Lock writeLock = this.lock.writeLock();
/*  86:151 */     writeLock.lock();
/*  87:    */     try
/*  88:    */     {
/*  89:153 */       logger.debug("Adding datasource for Tenant Id: {}", tenantId);
/*  90:154 */       this.tenantDataSources.put(tenantId, dataSource);
/*  91:    */     }
/*  92:    */     finally
/*  93:    */     {
/*  94:156 */       writeLock.unlock();
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   private DataSource getDataSourceBasedOnTenant()
/*  99:    */   {
/* 100:167 */     DataSource retVal = null;
/* 101:168 */     Lock readLock = this.lock.readLock();
/* 102:169 */     readLock.lock();
/* 103:    */     try
/* 104:    */     {
/* 105:171 */       logger.debug("Attempting to find tenant id for the datasource");
/* 106:172 */       if (TransactionSynchronizationManager.hasResource("tenantIdentifier"))
/* 107:    */       {
/* 108:173 */         String tenantId = (String)TransactionSynchronizationManager.getResource("tenantIdentifier");
/* 109:175 */         if (tenantId != null)
/* 110:    */         {
/* 111:176 */           logger.debug("Using tenant id: {}", tenantId);
/* 112:177 */           retVal = (DataSource)this.tenantDataSources.get(tenantId);
/* 113:    */         }
/* 114:    */       }
/* 115:    */     }
/* 116:    */     finally
/* 117:    */     {
/* 118:181 */       readLock.unlock();
/* 119:    */     }
/* 120:183 */     return retVal != null ? retVal : this.defaultDataSource;
/* 121:    */   }
/* 122:    */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.MultiTenantDataSourceImpl
 * JD-Core Version:    0.7.0.1
 */
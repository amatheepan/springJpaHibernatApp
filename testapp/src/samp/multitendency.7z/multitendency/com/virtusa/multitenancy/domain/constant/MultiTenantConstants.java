package com.virtusa.multitenancy.domain.constant;

public abstract interface MultiTenantConstants
{
  public static final String tenantIdentifier = "tenantIdentifier";
}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.domain.constant.MultiTenantConstants
 * JD-Core Version:    0.7.0.1
 */
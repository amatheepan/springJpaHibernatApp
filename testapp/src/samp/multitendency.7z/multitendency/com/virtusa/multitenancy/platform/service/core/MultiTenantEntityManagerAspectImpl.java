/*   1:    */ package com.virtusa.multitenancy.platform.service.core;
/*   2:    */ 
/*   3:    */ import com.virtusa.multitenancy.domain.constant.TenantIdentification;
/*   4:    */ import com.virtusa.multitenancy.platform.service.internal.EntityManagerInjector;
/*   5:    */ import com.virtusa.multitenancy.platform.util.ReflectionUtil;
/*   6:    */ import java.lang.annotation.Annotation;
/*   7:    */ import java.lang.reflect.InvocationTargetException;
/*   8:    */ import java.lang.reflect.Method;
/*   9:    */ import org.apache.commons.beanutils.BeanUtils;
/*  10:    */ import org.aspectj.lang.ProceedingJoinPoint;
/*  11:    */ import org.aspectj.lang.reflect.MethodSignature;
/*  12:    */ import org.slf4j.Logger;
/*  13:    */ import org.slf4j.LoggerFactory;
/*  14:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  15:    */ 
/*  16:    */ public class MultiTenantEntityManagerAspectImpl
/*  17:    */ {
/*  18: 30 */   private static Logger logger = LoggerFactory.getLogger(MultiTenantEntityManagerAspectImpl.class);
/*  19:    */   private String beanPath;
/*  20:    */   @Autowired
/*  21:    */   private EntityManagerInjector entityManagerInjector;
/*  22:    */   
/*  23:    */   public MultiTenantEntityManagerAspectImpl(String beanPath)
/*  24:    */   {
/*  25: 44 */     this.beanPath = beanPath;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public Object inject(ProceedingJoinPoint p)
/*  29:    */     throws Throwable
/*  30:    */   {
/*  31: 57 */     Object retVal = null;
/*  32: 58 */     logger.debug("Fetching tenant id");
/*  33: 59 */     String tenantId = getTenantId(p);
/*  34: 60 */     logger.debug("Fetched tenant id: {}", tenantId);
/*  35: 61 */     boolean injected = tenantId != null ? this.entityManagerInjector.inject(tenantId) : false;
/*  36: 62 */     if ((injected) && (logger.isDebugEnabled())) {
/*  37: 63 */       logger.debug("Injected Entity Manager");
/*  38:    */     }
/*  39:    */     try
/*  40:    */     {
/*  41: 66 */       retVal = p.proceed();
/*  42:    */     }
/*  43:    */     catch (Throwable e)
/*  44:    */     {
/*  45: 68 */       throw e;
/*  46:    */     }
/*  47:    */     finally
/*  48:    */     {
/*  49: 70 */       if (injected) {
/*  50: 71 */         this.entityManagerInjector.remove(tenantId);
/*  51:    */       }
/*  52:    */     }
/*  53: 74 */     return retVal;
/*  54:    */   }
/*  55:    */   
/*  56:    */   private String getTenantId(ProceedingJoinPoint p)
/*  57:    */   {
/*  58: 85 */     int argIndex = getMultitenantArgumentIndex(p);
/*  59: 86 */     String retVal = null;
/*  60: 87 */     if (argIndex != -1)
/*  61:    */     {
/*  62: 88 */       Object tenantArg = p.getArgs()[argIndex];
/*  63: 89 */       if ((tenantArg != null) && (this.beanPath != null)) {
/*  64:    */         try
/*  65:    */         {
/*  66: 91 */           retVal = BeanUtils.getProperty(tenantArg, this.beanPath);
/*  67:    */         }
/*  68:    */         catch (IllegalAccessException|InvocationTargetException|NoSuchMethodException e)
/*  69:    */         {
/*  70: 93 */           logger.warn("Unable to find the property: " + this.beanPath + " for object with class: " + tenantArg.getClass(), e);
/*  71:    */         }
/*  72:    */       } else {
/*  73: 98 */         retVal = tenantArg != null ? tenantArg.toString() : null;
/*  74:    */       }
/*  75:    */     }
/*  76:101 */     return retVal;
/*  77:    */   }
/*  78:    */   
/*  79:    */   private static int getMultitenantArgumentIndex(ProceedingJoinPoint p)
/*  80:    */   {
/*  81:112 */     int retVal = -1;
/*  82:    */     
/*  83:114 */     MethodSignature signature = (MethodSignature)p.getSignature();
/*  84:115 */     String methodName = signature.getMethod().getName();
/*  85:    */     try
/*  86:    */     {
/*  87:117 */       Method method = ReflectionUtil.getMethod(p.getTarget().getClass(), methodName);
/*  88:118 */       Annotation[][] annotations = method != null ? method.getParameterAnnotations() : new Annotation[0][];
/*  89:119 */       for (int i = 0; i < annotations.length; i++) {
/*  90:120 */         for (Annotation paramAnnotation : annotations[i]) {
/*  91:121 */           if (TenantIdentification.class.equals(paramAnnotation.annotationType()))
/*  92:    */           {
/*  93:122 */             retVal = i;
/*  94:123 */             break;
/*  95:    */           }
/*  96:    */         }
/*  97:    */       }
/*  98:    */     }
/*  99:    */     catch (SecurityException e)
/* 100:    */     {
/* 101:128 */       logger.warn("Error while trying to find the tenant identifier", e);
/* 102:    */     }
/* 103:130 */     return retVal;
/* 104:    */   }
/* 105:    */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.MultiTenantEntityManagerAspectImpl
 * JD-Core Version:    0.7.0.1
 */
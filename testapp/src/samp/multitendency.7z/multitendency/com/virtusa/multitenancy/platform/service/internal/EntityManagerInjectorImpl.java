/*  1:   */ package com.virtusa.multitenancy.platform.service.internal;
/*  2:   */ 
/*  3:   */ import org.springframework.stereotype.Service;
/*  4:   */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  5:   */ 
/*  6:   */ @Service
/*  7:   */ public class EntityManagerInjectorImpl
/*  8:   */   implements EntityManagerInjector
/*  9:   */ {
/* 10:   */   public boolean inject(String tenantId)
/* 11:   */   {
/* 12:29 */     boolean retVal = false;
/* 13:30 */     if (!TransactionSynchronizationManager.hasResource("tenantIdentifier"))
/* 14:   */     {
/* 15:31 */       TransactionSynchronizationManager.bindResource("tenantIdentifier", tenantId);
/* 16:32 */       retVal = true;
/* 17:   */     }
/* 18:34 */     return retVal;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void remove(String tenantId)
/* 22:   */   {
/* 23:46 */     TransactionSynchronizationManager.unbindResourceIfPossible("tenantIdentifier");
/* 24:   */   }
/* 25:   */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.internal.EntityManagerInjectorImpl
 * JD-Core Version:    0.7.0.1
 */
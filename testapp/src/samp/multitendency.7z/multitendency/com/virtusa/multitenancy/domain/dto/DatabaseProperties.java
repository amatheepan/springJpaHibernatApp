/*  1:   */ package com.virtusa.multitenancy.domain.dto;
/*  2:   */ 
/*  3:   */ public class DatabaseProperties
/*  4:   */ {
/*  5:   */   private String driverClassName;
/*  6:   */   private String userName;
/*  7:   */   private String password;
/*  8:   */   private String url;
/*  9:   */   
/* 10:   */   public String getDriverClassName()
/* 11:   */   {
/* 12:27 */     return this.driverClassName;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setDriverClassName(String driverClassName)
/* 16:   */   {
/* 17:37 */     this.driverClassName = driverClassName;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getUserName()
/* 21:   */   {
/* 22:46 */     return this.userName;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setUserName(String userName)
/* 26:   */   {
/* 27:56 */     this.userName = userName;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getPassword()
/* 31:   */   {
/* 32:65 */     return this.password;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setPassword(String password)
/* 36:   */   {
/* 37:75 */     this.password = password;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getUrl()
/* 41:   */   {
/* 42:84 */     return this.url;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setUrl(String url)
/* 46:   */   {
/* 47:94 */     this.url = url;
/* 48:   */   }
/* 49:   */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.domain.dto.DatabaseProperties
 * JD-Core Version:    0.7.0.1
 */
package com.virtusa.multitenancy.platform.service.internal;

public abstract interface EntityManagerInjector
{
  public abstract boolean inject(String paramString);
  
  public abstract void remove(String paramString);
}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.internal.EntityManagerInjector
 * JD-Core Version:    0.7.0.1
 */
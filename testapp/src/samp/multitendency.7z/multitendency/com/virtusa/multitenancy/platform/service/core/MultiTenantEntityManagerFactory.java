package com.virtusa.multitenancy.platform.service.core;

import javax.persistence.EntityManagerFactory;

public abstract interface MultiTenantEntityManagerFactory
  extends EntityManagerFactory
{
  public abstract void addTenant(String paramString, EntityManagerFactory paramEntityManagerFactory);
}


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.MultiTenantEntityManagerFactory
 * JD-Core Version:    0.7.0.1
 */
/*   1:    */ package com.virtusa.multitenancy.platform.service.core;
/*   2:    */ 
/*   3:    */ import com.virtusa.multitenancy.domain.dto.DatabaseProperties;
/*   4:    */ import javax.naming.NamingException;
/*   5:    */ import javax.persistence.EntityManagerFactory;
/*   6:    */ import javax.sql.DataSource;
/*   7:    */ import org.apache.commons.dbcp.BasicDataSource;
/*   8:    */ import org.springframework.beans.BeansException;
/*   9:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  10:    */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*  11:    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*  12:    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*  13:    */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*  14:    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*  15:    */ import org.springframework.context.ApplicationContext;
/*  16:    */ import org.springframework.context.ApplicationContextAware;
/*  17:    */ import org.springframework.jndi.JndiObjectFactoryBean;
/*  18:    */ import org.springframework.jndi.JndiTemplate;
/*  19:    */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*  20:    */ import org.springframework.stereotype.Service;
/*  21:    */ 
/*  22:    */ @Service
/*  23:    */ public class TenantEntityManagerFactoryCreatorImpl
/*  24:    */   implements TenantEntityManagerFactoryCreator, ApplicationContextAware
/*  25:    */ {
/*  26:    */   private static final String DATASOURCE = "dataSource";
/*  27:    */   private static final String PERSISTENCE_UNIT_NAME = "persistenceUnitName";
/*  28:    */   private static final String JNDI_TEMPLATE = "jndiTemplate";
/*  29:    */   private static final String JNDI_NAME = "jndiName";
/*  30:    */   private static final String RESOURCE_REF = "resourceRef";
/*  31:    */   private static final String CLOSE_METHOD = "close";
/*  32:    */   private static final String DRIVER_CLASS_NAME = "driverClassName";
/*  33:    */   private static final String USER_NAME = "username";
/*  34:    */   private static final String PASSWORD = "password";
/*  35:    */   private static final String URL = "url";
/*  36:    */   private ApplicationContext applicationContext;
/*  37:    */   @Autowired
/*  38:    */   private MultiTenantEntityManagerFactory multiTenantEntityManagerFactory;
/*  39:    */   @Autowired(required=false)
/*  40:    */   private MultiTenantDataSource multiTenantDataSource;
/*  41:    */   
/*  42:    */   public void createEntityManagerFactoryUsingJndiDataSource(String datasourceJndiName, String persistenceUnitName, String parentName)
/*  43:    */     throws NamingException
/*  44:    */   {
/*  45: 78 */     AbstractBeanDefinition jndiBeanDefinition = BeanDefinitionBuilder.genericBeanDefinition(JndiTemplate.class).getBeanDefinition();
/*  46:    */     
/*  47: 80 */     String jndiBeanName = registerBeanDefinition(jndiBeanDefinition, false);
/*  48:    */     
/*  49:    */ 
/*  50: 83 */     AbstractBeanDefinition dataSourceBeanDefinition = BeanDefinitionBuilder.genericBeanDefinition(JndiObjectFactoryBean.class).addPropertyReference("jndiTemplate", jndiBeanName).addPropertyValue("jndiName", datasourceJndiName).addPropertyValue("resourceRef", Boolean.valueOf(true)).getBeanDefinition();
/*  51:    */     
/*  52:    */ 
/*  53:    */ 
/*  54: 87 */     String dataSourceBeanName = registerBeanDefinition(dataSourceBeanDefinition, false);
/*  55: 88 */     createAndInject(persistenceUnitName, parentName, dataSourceBeanName);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void createEntityManagerFactoryWithProvidedDatasource(DatabaseProperties databaseProperties, String persistenceUnitName, String parentName)
/*  59:    */   {
/*  60:103 */     AbstractBeanDefinition dataSourceBeanDefinition = BeanDefinitionBuilder.genericBeanDefinition(BasicDataSource.class).setDestroyMethodName("close").addPropertyValue("driverClassName", databaseProperties.getDriverClassName()).addPropertyValue("username", databaseProperties.getUserName()).addPropertyValue("password", databaseProperties.getPassword()).addPropertyValue("url", databaseProperties.getUrl()).getBeanDefinition();
/*  61:    */     
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:110 */     String dataSourceBeanName = registerBeanDefinition(dataSourceBeanDefinition, false);
/*  68:111 */     createAndInject(persistenceUnitName, parentName, dataSourceBeanName);
/*  69:    */   }
/*  70:    */   
/*  71:    */   private void createAndInject(String persistenceUnitName, String parentName, String dataSourceBeanName)
/*  72:    */   {
/*  73:125 */     if ((parentName != null) && 
/*  74:126 */       (!this.applicationContext.containsBeanDefinition(parentName))) {
/*  75:127 */       throw new RuntimeException("Parent bean with name: " + parentName + " is not defined");
/*  76:    */     }
/*  77:131 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(LocalContainerEntityManagerFactoryBean.class).addPropertyReference("dataSource", dataSourceBeanName).addPropertyValue("persistenceUnitName", persistenceUnitName);
/*  78:    */     
/*  79:    */ 
/*  80:    */ 
/*  81:135 */     AbstractBeanDefinition emBeanDefinition = parentName != null ? builder.setParentName(parentName).getBeanDefinition() : builder.getBeanDefinition();
/*  82:    */     
/*  83:137 */     String innerBeanName = registerBeanDefinition(emBeanDefinition, true);
/*  84:138 */     this.multiTenantEntityManagerFactory.addTenant(persistenceUnitName, (EntityManagerFactory)this.applicationContext.getBean(innerBeanName, EntityManagerFactory.class));
/*  85:141 */     if (this.multiTenantDataSource != null) {
/*  86:142 */       this.multiTenantDataSource.addTenant(persistenceUnitName, (DataSource)this.applicationContext.getBean(dataSourceBeanName, DataSource.class));
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setApplicationContext(ApplicationContext applicationContext)
/*  91:    */     throws BeansException
/*  92:    */   {
/*  93:157 */     this.applicationContext = applicationContext;
/*  94:    */   }
/*  95:    */   
/*  96:    */   private String registerBeanDefinition(AbstractBeanDefinition beanDefinition, boolean isInnerBean)
/*  97:    */   {
/*  98:170 */     BeanDefinitionRegistry registry = (BeanDefinitionRegistry)this.applicationContext.getAutowireCapableBeanFactory();
/*  99:171 */     String beanName = BeanDefinitionReaderUtils.generateBeanName(beanDefinition, registry, isInnerBean);
/* 100:172 */     BeanDefinitionHolder holder = new BeanDefinitionHolder(beanDefinition, beanName);
/* 101:173 */     BeanDefinitionReaderUtils.registerBeanDefinition(holder, registry);
/* 102:174 */     return beanName;
/* 103:    */   }
/* 104:    */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.TenantEntityManagerFactoryCreatorImpl
 * JD-Core Version:    0.7.0.1
 */
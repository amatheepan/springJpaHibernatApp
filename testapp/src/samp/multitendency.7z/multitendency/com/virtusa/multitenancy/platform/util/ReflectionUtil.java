/*  1:   */ package com.virtusa.multitenancy.platform.util;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Method;
/*  4:   */ 
/*  5:   */ public class ReflectionUtil
/*  6:   */ {
/*  7:   */   public static Method getMethod(Class<?> clazz, String methodName)
/*  8:   */   {
/*  9:33 */     Method retVal = null;
/* 10:34 */     for (Method method : clazz.getDeclaredMethods()) {
/* 11:35 */       if (methodName.equals(method.getName()))
/* 12:   */       {
/* 13:36 */         retVal = method;
/* 14:37 */         break;
/* 15:   */       }
/* 16:   */     }
/* 17:41 */     Class<?> superClazz = clazz.getSuperclass();
/* 18:42 */     if ((retVal == null) && (!Object.class.equals(superClazz))) {
/* 19:43 */       retVal = getMethod(superClazz, methodName);
/* 20:   */     }
/* 21:45 */     return retVal;
/* 22:   */   }
/* 23:   */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.util.ReflectionUtil
 * JD-Core Version:    0.7.0.1
 */
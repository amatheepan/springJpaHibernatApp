/*   1:    */ package com.virtusa.multitenancy.platform.service.core;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.concurrent.locks.Lock;
/*   6:    */ import java.util.concurrent.locks.ReadWriteLock;
/*   7:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*   8:    */ import javax.persistence.Cache;
/*   9:    */ import javax.persistence.EntityManager;
/*  10:    */ import javax.persistence.EntityManagerFactory;
/*  11:    */ import javax.persistence.PersistenceUnitUtil;
/*  12:    */ import javax.persistence.criteria.CriteriaBuilder;
/*  13:    */ import javax.persistence.metamodel.Metamodel;
/*  14:    */ import org.slf4j.Logger;
/*  15:    */ import org.slf4j.LoggerFactory;
/*  16:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  17:    */ 
/*  18:    */ public class MultiTenantEntityManagerFactoryImpl
/*  19:    */   implements MultiTenantEntityManagerFactory
/*  20:    */ {
/*  21: 34 */   private static Logger logger = LoggerFactory.getLogger(MultiTenantEntityManagerFactoryImpl.class);
/*  22:    */   private EntityManagerFactory defaultFactory;
/*  23: 38 */   private Map<String, EntityManagerFactory> emFactories = new HashMap();
/*  24: 40 */   private ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*  25:    */   
/*  26:    */   public MultiTenantEntityManagerFactoryImpl(EntityManagerFactory defaultFactory)
/*  27:    */   {
/*  28: 49 */     this.defaultFactory = defaultFactory;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public EntityManager createEntityManager()
/*  32:    */   {
/*  33: 59 */     return getEntityManagerFactory().createEntityManager();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public EntityManager createEntityManager(Map map)
/*  37:    */   {
/*  38: 70 */     return getEntityManagerFactory().createEntityManager(map);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public CriteriaBuilder getCriteriaBuilder()
/*  42:    */   {
/*  43: 80 */     return getEntityManagerFactory().getCriteriaBuilder();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Metamodel getMetamodel()
/*  47:    */   {
/*  48: 90 */     return getEntityManagerFactory().getMetamodel();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean isOpen()
/*  52:    */   {
/*  53:100 */     return getEntityManagerFactory().isOpen();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void close()
/*  57:    */   {
/*  58:110 */     getEntityManagerFactory().close();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Map<String, Object> getProperties()
/*  62:    */   {
/*  63:120 */     return getEntityManagerFactory().getProperties();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Cache getCache()
/*  67:    */   {
/*  68:130 */     return getEntityManagerFactory().getCache();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public PersistenceUnitUtil getPersistenceUnitUtil()
/*  72:    */   {
/*  73:140 */     return getEntityManagerFactory().getPersistenceUnitUtil();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void addTenant(String tenantId, EntityManagerFactory entityManagerFactory)
/*  77:    */   {
/*  78:152 */     Lock writeLock = this.lock.writeLock();
/*  79:153 */     writeLock.lock();
/*  80:    */     try
/*  81:    */     {
/*  82:155 */       logger.debug("Adding factory for Tenant Id: {}", tenantId);
/*  83:156 */       this.emFactories.put(tenantId, entityManagerFactory);
/*  84:    */     }
/*  85:    */     finally
/*  86:    */     {
/*  87:158 */       writeLock.unlock();
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   private EntityManagerFactory getEntityManagerFactory()
/*  92:    */   {
/*  93:169 */     EntityManagerFactory retVal = null;
/*  94:170 */     Lock readLock = this.lock.readLock();
/*  95:171 */     readLock.lock();
/*  96:    */     try
/*  97:    */     {
/*  98:173 */       logger.debug("Attempting to find tenant id");
/*  99:174 */       if (TransactionSynchronizationManager.hasResource("tenantIdentifier"))
/* 100:    */       {
/* 101:175 */         String tenantId = (String)TransactionSynchronizationManager.getResource("tenantIdentifier");
/* 102:177 */         if (tenantId != null)
/* 103:    */         {
/* 104:178 */           logger.debug("Using tenant id: {}", tenantId);
/* 105:179 */           retVal = (EntityManagerFactory)this.emFactories.get(tenantId);
/* 106:    */         }
/* 107:    */       }
/* 108:    */     }
/* 109:    */     finally
/* 110:    */     {
/* 111:183 */       readLock.unlock();
/* 112:    */     }
/* 113:185 */     return retVal != null ? retVal : this.defaultFactory;
/* 114:    */   }
/* 115:    */ }


/* Location:           .\
 * Qualified Name:     com.virtusa.multitenancy.platform.service.core.MultiTenantEntityManagerFactoryImpl
 * JD-Core Version:    0.7.0.1
 */